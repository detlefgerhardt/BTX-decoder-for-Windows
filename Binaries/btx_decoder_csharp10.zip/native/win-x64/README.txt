Place SDL3.dll here for Windows x64.
The build copies this folder to output and the app loads SDL3.dll from it.

Lege hier die native SDL3-Bibliothek ab, damit das Projekt sie direkt mit ausliefert.

Linux (x64):
- `libSDL3.so` oder
- `libSDL3.so.0`

Der Build kopiert den Inhalt von `native/` automatisch ins Ausgabeverzeichnis.
Der Loader versucht beim Start zuerst diese lokalen Dateien zu laden.
